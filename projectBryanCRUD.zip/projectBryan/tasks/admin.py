from django.contrib import admin
from .models import tasks

admin.site.register(tasks)